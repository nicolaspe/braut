

ABOUT
——

Bajern is a typeface inspired by German frakturs with a twist of Sweden. 
It's like german engineering combined with allemansrätt. 
Like oktoberfest combined with smörgåsbord.
Yeah you get it. Enjoy the free typeface!

Designed by Anton Bolin at Hökarängens Bokstavsfabrik 2016.


LICENSE
——

This font is free for personal and commercial use. 


PROHBITIONS
——

You do not have the rights to redistribute, resell, lease, license, sublicense or sell Bajern without permission. If you wish to promote Bajern on your site, you must link back to the resource page where users can find the download and not directly to the download file.


CONTACT
——
Anton Bolin
anton.bolin@gmail.com
antonbolin.se
behance.com/antonbolin






